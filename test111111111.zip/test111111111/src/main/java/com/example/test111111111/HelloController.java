package com.example.test111111111;

import javafx.fxml.FXML;
import javafx.scene.control.Label;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;

public class HelloController {
    @FXML
    private Label messageVal;
    @FXML
    private TextField username;
    @FXML
    private PasswordField password;

    private int counting;

    @FXML
    protected void onHelloButtonClick() {

    String usernameVal = username.getText();
    String passwordVal = password.getText();



        if (usernameVal.isEmpty() || passwordVal.isEmpty()) {
        messageVal.setText("Please provide username and password.");
    } else if (usernameVal.equals("Jasbir") && passwordVal.equals("0808")) {
        messageVal.setText("Success!!!");
    } else {
        counting++;
        if (counting >= 5) {
            messageVal.setText("Sorry, Your Account is Locked!!");
        } else {
            messageVal.setText("Sorry, invalid username or password ");
        }
     }

    }

}