module com.example.test111111111 {
    requires javafx.controls;
    requires javafx.fxml;


    opens com.example.test111111111 to javafx.fxml;
    exports com.example.test111111111;
}